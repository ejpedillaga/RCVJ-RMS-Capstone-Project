<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Side RCVJ</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>

    <style>
        /* DIALOG BOX CSS */
        .rejected-dialog-box {
            width: 1100px;
            height: 402px;
            border-radius: 20px;
            background-color: #fff;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            box-sizing: border-box;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            display: none;
            z-index: 1000;
        }
        .rejected-back-button {
            font-size: 24px;
            margin-bottom: 20px;
            cursor: pointer;
        }

        .rejected-form-group {
            margin-bottom: 20px;
            padding-right: 20px;
        }
        .rejected-form-group label {
            font-size: 24px;
            display: block;
            margin-bottom: 10px;
        }
        .rejected-form-group input, .rejected-form-group textarea {
            width: 100%;
            height: 59px;
            border-radius: 10px;
            border: 1px solid #ccc;
            padding: 10px;
            font-size: 24px;
            box-sizing: border-box;

        }
        .rejected-form-group textarea {
            height: 268px;
            resize: none;
        }
        .rejected-save-button {
            background-color: #ffa500;
            border: none;
            border-radius: 10px;
            padding: 15px 30px;
            font-size: 24px;
            cursor: pointer;
            position: absolute;
            bottom: 60px;
            right: 60px;
        }

    </style>
      
</head>
<body>
    <div id="mySidebar" class="sidebar">
        <div class="sidebar-header">
            <h3>RCVJ Inc.</h3>
            <button class="toggle-btn" onclick="toggleNav()">
                <i class="fas fa-bars"></i>
            </button>
        </div>
            <a href="employeeHome.php"><i class="fa-solid fa-suitcase"></i> <span>Jobs</span></a>
            <a href="smartsearch.php"><i class="fa-solid fa-magnifying-glass"></i> <span>Smart Search</span></a>
            <a href="candidates.php" class="active" style="color: #EF9B50;"><i class="fa-solid fa-user"></i></i> <span>Candidates</span></a>
            <a href="schedules.php" ><i class="fa-solid fa-calendar"></i></i> <span>Schedules</span></a>
            <a href="partners.php"><i class="fa-solid fa-handshake"></i> <span>Partners</span></a>
        </div>

        <div id="header">
            <img id="logo" src="img/logo.png" alt="logo">
            <div class="profile">
                <img src="img/pfp.png" alt="Profile Picture">
                <span class="name">Employee</span>
            </div>
        </div>

        <div id="main">
            <h2 style="font-size: 36px;">Candidates</h2>

            <div class="filter-container">
                <div class="search-wrapper">
                    <i class="fas fa-magnifying-glass search-icon"></i>
                    <input type="text" class="search-candidates" placeholder="Search Candidates">
                </div>
                <select class="company-sort">
                    <option>Sort by: All</option>
                    <option>Sort by: WalterMart</option>
                    <option>Sort by: Jabile</option>
                </select>
                <select class="sort-by">
                    <option>Sort by: Date Applied</option>
                    <option>Sort by: Company Name</option>
                    <option>Sort by: Job Title</option>
                </select>
                <select class="order-sort">
                    <option>Ascending</option>
                    <option>Descending</option>
                </select>

                <select class="status-sort">
                    <option>Status: Interview</option>
                    <option>Status: Pending</option>
                    <option>Status: Deployed</option>
                </select>

                <div>
                    <a href="rejected.php">
                        <button class="reject-button">Rejected</button>
                    </a>
                </div>
            </div>

            <div>
                <table>
                    <tr class="th1">
                        <th>Candidate</th>
                        <th>Job Title</th>
                        <th>Company</th>
                        <th>Date Applied</th>
                        <th>Status</th>
                        <th>Reject</th>
                    </tr>

                    <tr class="spaceunder">
                        <td></td>
                    </tr>

                    <tr class="tr1">
                        <td class="fullname">Juan Miguel Escalante</td>
                        <td><strong>SUPERMARKET BAGGER</strong></td>
                        <td>WalterMart <br>Supermarket - Dasmarinas</td>
                        <td>5/13/2024</td>
                        <td>
                            <select class="status-dropdown">
                                <option>Interview</option>
                                <option>Pending</option>
                                <option>Rejected</option>
                            </select>
                        </td>
                        <td>
                            <i class="fa-solid fa-trash fa-2xl" style="color: #EF9B50; cursor: pointer;" onclick="showDialog()"></i>
                        </td>
                    </tr>

                    <tr class="spaceunder">
                        <td></td>
                    </tr>

                    <tr class="tr1">
                        <td class="fullname">Jason Angelo Mariano</td>
                        <td><strong>SUPERMARKET BAGGER</strong></td>
                        <td>WalterMart <br>Supermarket - Dasmarinas</td>
                        <td>5/13/2024</td>
                        <td>
                            <select class="status-dropdown">
                                <option>Interview</option>
                                <option>Pending</option>
                                <option>Rejected</option>
                            </select>
                        </td>
                        <td>
                            <i class="fa-solid fa-trash fa-2xl" style="color: #EF9B50; cursor: pointer;" onclick="showDialog()"></i>
                        </td>
                    </tr>

                    <tr class="spaceunder">
                        <td></td>
                    </tr>

                    <tr class="tr1">
                        <td class="fullname">Allyssa Jade Taruc</td>
                        <td><strong>Cashier</strong></td>
                        <td>WalterMart <br>Supermarket - Dasmarinas</td>
                        <td>5/13/2024</td>
                        <td>
                            <select class="status-dropdown">
                                <option>Interview</option>
                                <option>Pending</option>
                                <option>Deployed</option>
                            </select>
                        </td>
                        
                        <td>
                            <i class="fa-solid fa-trash fa-2xl" style="color: #EF9B50; cursor: pointer;" onclick="showDialog()"></i>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Dialog Box Candicates-->
        <div class="rejected-dialog-box" id="dialogBox">
            <div class="rejected-back-button" onclick="hideDialog()">← Back</div>
    
            <h1 style="font-size: 36px;">Are you sure you want to reject this candidate?</h1>
            <div class="rejected-form-group">
                <label for="rejected-firstname">Remarks:</label>
                <input type="text" id="rejected-firstname">
            </div>

        </div>

    </div>
</body>

