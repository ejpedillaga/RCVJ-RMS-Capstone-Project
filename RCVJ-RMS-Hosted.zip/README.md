# CAPSTONE-SYSTEM
- Escalante
- Mariano
- Pedillaga
- Taruc
